from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

import random
import itertools
author = 'Hamideh Mohtashami Borzadaran'

doc = """
This is a real effort task where subjects are asked to sum up 4 randomly selected 2 digit numbers. They will receive
 information on the number of correct responses they provide. 
"""


class Constants(BaseConstants):
    name_in_url = 'myExperiment'
    players_per_group = 2
    num_rounds = 5

# """Amount allocated to each player"""


class Subsession(BaseSubsession):
    def creating_session(self):
        # real effort task
        for p in self.get_players():
            rand = [int(10), int(11), int(12), int(13), int(14), int(15), int(16), int(17), int(18), int(19),
                    int(20), int(21), int(22), int(23), int(24), int(25), int(26), int(27), int(28), int(29),
                    int(30), int(31), int(32), int(33), int(34), int(35), int(36), int(37), int(38), int(39),
                    int(40), int(41), int(42), int(43), int(44), int(45), int(46), int(47), int(48), int(49),
                    int(50), int(51), int(52), int(53), int(54), int(55), int(56), int(57), int(58), int(59),
                    int(60), int(61), int(62), int(63), int(64), int(65), int(66), int(67), int(68), int(69),
                    int(70), int(71), int(72), int(73), int(74), int(75), int(76), int(77), int(78), int(79),
                    int(80), int(81), int(82), int(83), int(84), int(85), int(86), int(87), int(88), int(89),
                    int(90), int(91), int(92), int(93), int(94), int(95), int(96), int(97), int(98), int(99)]
            p.digits1 = random.choice(rand)
            p.digits2 = random.choice(rand)
            p.digits3 = random.choice(rand)
            p.digits4 = random.choice(rand)

            p.Sum_digits = p.digits1 + p.digits2 + p.digits3 + p.digits4


class Group(BaseGroup):
    sum_of_correct = models.IntegerField(label='', initial=0)

    def set_treatment(self):
        self.in_round(Constants.num_rounds).sum_of_correct = sum([p.in_round(Constants.num_rounds).total_correct for
                                                                  p in self.get_players()])
        for p in self.get_players():
            p.in_round(Constants.num_rounds).other_correct = \
                self.in_round(Constants.num_rounds).sum_of_correct - p.in_round(Constants.num_rounds).total_correct


class Player(BasePlayer):
    digits1 = models.IntegerField()
    digits2 = models.IntegerField()
    digits3 = models.IntegerField()
    digits4 = models.IntegerField()
    Sum_digits = models.IntegerField(label='', min=40, max=396)

    digit_response = models.IntegerField(label='', min=40, max=396)
    answer = models.IntegerField()
    correct = models.IntegerField(label='', initial=0)
    incorrect = models.IntegerField(label='', initial=0)

    def correct_answers(self):
        if self.digit_response == self.Sum_digits:
            self.correct = 1
        elif self.digit_response == '':
            self.correct = 0
            self.incorrect = 0
        elif self.digit_response == 0:
            self.correct = 0
            self.incorrect = 0
        else:
            self.incorrect = 1

    totalNumAttempted = models.FloatField()
    totalNumCorrect = models.IntegerField()
    total_correct = models.IntegerField(label='', initial=0)
    other_correct = models.IntegerField(label='', initial=0)
    sum_of_correct = models.IntegerField(label='', initial=0)
    total_incorrect = models.IntegerField(label='', initial=0)
    correct_prev = models.IntegerField(label='', initial=0)

    def sum_answer(self):
        self.totalNumCorrect = sum([p.correct for p in self.in_all_rounds()])

    def prev_correct(self):
        if self.round_number < Constants.num_rounds:
            self.in_round(self.round_number+1).correct_prev = self.in_round(self.round_number).totalNumCorrect
        elif self.round_number == Constants.num_rounds:
            self.in_round(self.round_number).correct_prev = self.in_round(self.round_number).totalNumCorrect
        else:
            self.correct_prev = 0

    def show_answer(self):
        self.in_round(Constants.num_rounds).total_correct = sum([p.correct for p in self.in_all_rounds()])
        self.in_round(Constants.num_rounds).total_incorrect = sum([p.incorrect for p in self.in_all_rounds()])
        self.in_round(Constants.num_rounds).totalNumAttempted = \
            self.in_round(Constants.num_rounds).total_correct + self.in_round(Constants.num_rounds).total_incorrect
        self.in_round(Constants.num_rounds).sum_of_correct = \
            self.in_round(Constants.num_rounds).group.sum_of_correct
    ##########################################################


